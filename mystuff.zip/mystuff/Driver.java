package mystuff;

public class Driver {
    public static void main(String[] args) {

        // Create object
        Driver myDriver = new Driver();

        // Fill the new myDriver object's data fields
        myDriver.firstName = "Juan";
        myDriver.lastname = "Solis";
        myDriver.licensedate = "06/01/2020";
        myDriver.licensetype = "Class C";
        myDriver.car = "Ford";

        System.out.println("\n The first name of the driver is: " + myDriver.firstName + "\n");
        System.out.println("\n The last name of the driver is: " + myDriver.lastname + "\n");

}
