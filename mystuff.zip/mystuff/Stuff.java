package mystuff;

public class Stuff {
    public static void main(String[] args) {

        // Create object
        Stuff myStuff = new Stuff();

        // Fill the new myStuff object's data fields
        myStuff.walletbrand = "Calvin";
        myStuff.shoesbrand = "Solis";

        System.out.println("\n The name of the first item is: " + myStuff.walletbrand + "\n");

    }

