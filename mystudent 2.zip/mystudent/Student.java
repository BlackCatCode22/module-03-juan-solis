package mystudent;

public class Student {
    String firstName;
    String lastname;
    double gpa;
    String major;
    String city;
}
